
Restoration comments May/2018

SOAP II 
From Bitsavers Manual 24-4000-0_SOAPII.pdf 

It can assemble itself, but the generated code is not the same
as the one in the source code listing

This is the result of a probable manual tuning/patch of
assembled code.